-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: sit_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_admin_users_email` (`email`),
  KEY `ix_admin_users_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (2,'admin@example.com','$2b$12$yOtOYjhXYWR9aCNN2kfUA...lIRlDEF6flMFTSe2UnVmuqBBVGPqm','admin','2026-02-26 04:10:02'),(3,'bot@example.com','$2b$12$FeiPl/p.l.opRYaSEaAi8u07EzGPilFKevVURMcMfqh5RltUxNOqO','admin','2026-02-26 04:27:15');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actor_email` varchar(255) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_audit_logs_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:08:18'),(2,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:08:27'),(3,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:08:47'),(4,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:10:43'),(5,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:11:09'),(6,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:13:56'),(7,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:26:13'),(8,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:26:14'),(9,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:26:17'),(10,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:26:20'),(11,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:26:51'),(12,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:27:43'),(13,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:27:45'),(14,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8001/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 04:28:34'),(15,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:29:10'),(16,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:29:25'),(17,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8001/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 04:29:30'),(18,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:29:53'),(19,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:31:44'),(20,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:32:15'),(21,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:32:56'),(22,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:33:03'),(23,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8001/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 04:33:08'),(24,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:33:23'),(25,'admin@example.com','POST /reports','http://127.0.0.1:8001/reports','127.0.0.1',NULL,NULL,'2026-02-26 04:36:11'),(26,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:37:36'),(27,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8001/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 04:37:41'),(28,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:37:55'),(29,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:37:59'),(30,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:00'),(31,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:01'),(32,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:01'),(33,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:05'),(34,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:06'),(35,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:06'),(36,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:07'),(37,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:08'),(38,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:16'),(39,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:38:16'),(40,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:38:28'),(41,'bot@example.com','POST /scans','http://127.0.0.1:8001/scans','127.0.0.1',NULL,NULL,'2026-02-26 04:38:32'),(42,'bot@example.com','POST /scans','http://127.0.0.1:8001/scans','127.0.0.1',NULL,NULL,'2026-02-26 04:38:32'),(43,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:39:38'),(44,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:40:12'),(45,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:40:14'),(46,'bot@example.com','POST /scans','http://127.0.0.1:8001/scans','127.0.0.1',NULL,NULL,'2026-02-26 04:40:15'),(47,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8001/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 04:40:20'),(48,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 04:40:35'),(49,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:43:07'),(50,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 04:47:33');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `started_at` timestamp NULL DEFAULT current_timestamp(),
  `finished_at` timestamp NULL DEFAULT NULL,
  `status` enum('success','failed','running') NOT NULL,
  `size_bytes` bigint(20) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `checksum_sha256` varchar(64) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backup_history_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_email` varchar(255) DEFAULT NULL,
  `scope_json` text DEFAULT NULL,
  `status` enum('queued','running','done','failed') NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `finished_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backups_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_scope` enum('all','admin','editor','viewer','selected') NOT NULL,
  `recipient_user_id` int(11) DEFAULT NULL,
  `type` enum('info','warning','alert','success') NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_notifications_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_user_id` bigint(20) DEFAULT NULL,
  `telegram_username` varchar(80) DEFAULT NULL,
  `link` text DEFAULT NULL,
  `report_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` enum('new','investigating','resolved') NOT NULL,
  `assignee` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_reports_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (1,NULL,NULL,'https://www.y8.com/','scam','FE','new',NULL,NULL,'2026-02-26 04:36:11');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scans`
--

DROP TABLE IF EXISTS `scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_user_id` bigint(20) DEFAULT NULL,
  `telegram_username` varchar(80) DEFAULT NULL,
  `link` text NOT NULL,
  `verdict` enum('safe','suspicious','scam') NOT NULL,
  `score` int(11) NOT NULL,
  `threat_level` varchar(10) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `breakdown` text DEFAULT NULL,
  `intel_summary` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_scans_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scans`
--

LOCK TABLES `scans` WRITE;
/*!40000 ALTER TABLE `scans` DISABLE KEYS */;
INSERT INTO `scans` VALUES (1,6936155788,NULL,'http://bit.ly/free-login','suspicious',51,'MED','Connection not encrypted (HTTP); Known shortener: bit.ly; Keywords: login, free; login; free','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL shortener\", \"points\": 18, \"detail\": \"Known shortener: bit.ly\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 14, \"detail\": \"Keywords: login, free\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 3, \"detail\": \"login\"}, {\"source\": \"nlp\", \"rule\": \"Reward / bait\", \"points\": 4, \"detail\": \"free\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://bit.ly/free-login','2026-02-26 04:38:32'),(2,6936155788,NULL,'http://bit.ly/free-login','suspicious',51,'MED','Connection not encrypted (HTTP); Known shortener: bit.ly; Keywords: login, free; login; free','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL shortener\", \"points\": 18, \"detail\": \"Known shortener: bit.ly\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 14, \"detail\": \"Keywords: login, free\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 3, \"detail\": \"login\"}, {\"source\": \"nlp\", \"rule\": \"Reward / bait\", \"points\": 4, \"detail\": \"free\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://bit.ly/free-login','2026-02-26 04:38:32'),(3,6936155788,NULL,'http://bit.ly/free-login','suspicious',51,'MED','Connection not encrypted (HTTP); Known shortener: bit.ly; Keywords: login, free; login; free','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL shortener\", \"points\": 18, \"detail\": \"Known shortener: bit.ly\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 14, \"detail\": \"Keywords: login, free\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 3, \"detail\": \"login\"}, {\"source\": \"nlp\", \"rule\": \"Reward / bait\", \"points\": 4, \"detail\": \"free\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://bit.ly/free-login','2026-02-26 04:40:15');
/*!40000 ALTER TABLE `scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('automatic_backup_enabled','true','2026-02-26 04:55:18'),('auto_backup','true','2026-02-26 04:42:42'),('backup_schedule','Daily 3:00 AM','2026-02-26 04:09:48'),('backup_time_of_day','03:00','2026-02-26 04:55:18'),('retention_days','7','2026-02-26 04:55:18'),('system_name','SIT Admin Panel','2026-02-26 04:09:48'),('timezone','Asia/Kuala_Lumpur','2026-02-26 04:09:48');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_security`
--

DROP TABLE IF EXISTS `user_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_security` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `totp_enabled` tinyint(1) NOT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  `mfa_required` tinyint(1) NOT NULL,
  `session_timeout_minutes` int(11) NOT NULL,
  `recovery_codes_hash` text DEFAULT NULL,
  `twofa_failed_attempts` int(11) NOT NULL,
  `twofa_locked_until` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `ix_user_security_id` (`id`),
  CONSTRAINT `user_security_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `admin_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_security`
--

LOCK TABLES `user_security` WRITE;
/*!40000 ALTER TABLE `user_security` DISABLE KEYS */;
INSERT INTO `user_security` VALUES (1,2,1,'JBSWY3DPEHPK3PXP',1,480,NULL,0,NULL);
/*!40000 ALTER TABLE `user_security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('admin','editor','viewer') NOT NULL,
  `status` enum('active','inactive','suspended') NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `last_login_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_email` (`email`),
  KEY `ix_users_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'sit_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-26 12:56:36
