-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: sit_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_admin_users_email` (`email`),
  KEY `ix_admin_users_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin@example.com','$2b$12$EgE842zTtRjZpxlQw6VskuhNSCt0ZJvsVmq9vz6v3okIKaUEmmszW','admin','2026-02-26 06:34:58'),(2,'bot@example.com','$2b$12$UgySZUzfc4pfg.0jL.K60uvAS29XbwqBbHmm6CmEuLr2ZM5AbYt6u','admin','2026-02-26 06:34:59'),(3,'nalcsbaru@gmail.com','$2b$12$ZbLeGg5PEXdSvcUpNMQ1JOgYgboqHTJ0qtdZjTwxtCeKKP.cqWYX6','admin','2026-02-26 08:59:14');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actor_email` varchar(255) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_audit_logs_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 06:40:54'),(2,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 06:41:05'),(3,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8001/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 06:41:10'),(4,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8001/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 06:41:30'),(5,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 07:04:33'),(6,'bot@example.com','POST /scans','http://127.0.0.1:8001/scans','127.0.0.1',NULL,NULL,'2026-02-26 07:04:37'),(7,'bot@example.com','POST /scans','http://127.0.0.1:8001/scans','127.0.0.1',NULL,NULL,'2026-02-26 07:04:37'),(8,'bot@example.com','POST /scans','http://127.0.0.1:8001/scans','127.0.0.1',NULL,NULL,'2026-02-26 07:04:50'),(9,'bot@example.com','POST /scans','http://127.0.0.1:8001/scans','127.0.0.1',NULL,NULL,'2026-02-26 07:05:01'),(10,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 07:06:20'),(11,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 07:12:44'),(12,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 07:31:46'),(13,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:09:59'),(14,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:11:59'),(15,'bot@example.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-02-26 08:12:46'),(16,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:56:57'),(17,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:56:58'),(18,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:57:10'),(19,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:57:10'),(20,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:57:15'),(21,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:57:29'),(22,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 08:57:39'),(23,NULL,'POST /auth/login','http://127.0.0.1:8001/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:02:21'),(24,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:02:45'),(25,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:03:20'),(26,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:03:24'),(27,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:04:53'),(28,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:05:05'),(29,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:05:14'),(30,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:08:25'),(31,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:12:47'),(32,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:12:49'),(33,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:15:28'),(34,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:15:38'),(35,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:17:08'),(36,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:17:20'),(37,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8002/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 09:18:01'),(38,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:18:22'),(39,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:18:24'),(40,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:18:24'),(41,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:18:24'),(42,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:18:25'),(43,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:18:31'),(44,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:19:17'),(45,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:19:18'),(46,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8002/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 09:19:22'),(47,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:19:30'),(48,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:19:41'),(49,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:19:43'),(50,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8002/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 09:19:48'),(51,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:20:01'),(52,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:20:03'),(53,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:25:51'),(54,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:29:57'),(55,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:33:27'),(56,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:34:41'),(57,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:34:47'),(58,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8002/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 09:34:51'),(59,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:35:00'),(60,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:35:01'),(61,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:37:52'),(62,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:41:25'),(63,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:45:56'),(64,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:46:00'),(65,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8002/auth/send-email-otp','127.0.0.1',NULL,NULL,'2026-02-26 09:46:04'),(66,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,NULL,'2026-02-26 09:46:12'),(67,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-02-26 09:48:07'),(68,'nalcsbaru@gmail.com','RUN_BACKUP',NULL,NULL,'{\"type\": \"db_only\"}',NULL,'2026-02-26 09:48:13'),(69,'nalcsbaru@gmail.com','POST /backup/run','http://127.0.0.1:8002/backup/run','127.0.0.1',NULL,NULL,'2026-02-26 09:48:13'),(70,'nalcsbaru@gmail.com','RUN_BACKUP',NULL,NULL,'{\"type\": \"db_only\"}',NULL,'2026-02-26 10:03:13'),(71,'nalcsbaru@gmail.com','POST /backup/run','http://127.0.0.1:8002/backup/run','127.0.0.1',NULL,NULL,'2026-02-26 10:03:13');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `started_at` timestamp NULL DEFAULT current_timestamp(),
  `finished_at` timestamp NULL DEFAULT NULL,
  `status` enum('success','failed','running') NOT NULL,
  `size_bytes` bigint(20) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `checksum_sha256` varchar(64) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `summary_file_path` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backup_history_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
INSERT INTO `backup_history` VALUES (1,'2026-02-26 01:48:13','2026-02-26 01:48:14','success',3756,'C:\\Users\\Ainal Aiman\\Documents\\Scammer Identification and Validation Tool\\backend\\backups\\backup-20260226-094813.zip','3cb9d7883b5a12c5ab027490d92706cff2c3f0c1edf26e8e4e602e0aa59a9fd5',NULL,'db_only','C:\\Users\\Ainal Aiman\\Documents\\Scammer Identification and Validation Tool\\backend\\backups\\backup-20260226-094813-summary.json'),(2,'2026-02-26 02:03:13',NULL,'running',NULL,NULL,NULL,NULL,'db_only',NULL);
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_email` varchar(255) DEFAULT NULL,
  `scope_json` text DEFAULT NULL,
  `status` enum('queued','running','done','failed') NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `finished_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backups_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_scope` enum('all','admin','editor','viewer','selected') NOT NULL,
  `recipient_user_id` int(11) DEFAULT NULL,
  `type` enum('info','warning','alert','success') NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_notifications_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_user_id` bigint(20) DEFAULT NULL,
  `telegram_username` varchar(80) DEFAULT NULL,
  `link` text DEFAULT NULL,
  `report_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` enum('new','investigating','resolved') NOT NULL,
  `assignee` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_reports_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scans`
--

DROP TABLE IF EXISTS `scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_user_id` bigint(20) DEFAULT NULL,
  `telegram_username` varchar(80) DEFAULT NULL,
  `link` text NOT NULL,
  `verdict` enum('safe','suspicious','scam') NOT NULL,
  `score` int(11) NOT NULL,
  `threat_level` varchar(10) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `breakdown` text DEFAULT NULL,
  `intel_summary` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_scans_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scans`
--

LOCK TABLES `scans` WRITE;
/*!40000 ALTER TABLE `scans` DISABLE KEYS */;
INSERT INTO `scans` VALUES (1,6936155788,NULL,'https://www.youtube.com/channel/UC9ui29SMJKPRCy0rx-Wv0VQ','safe',0,'LOW','No red flags','[]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','https://www.youtube.com/channel/UC9ui29SMJKPRCy0rx-Wv0VQ','2026-02-26 07:04:37'),(2,6936155788,NULL,'http://bit.ly/free-login','suspicious',51,'MED','Connection not encrypted (HTTP); Known shortener: bit.ly; Keywords: login, free; login; free','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL shortener\", \"points\": 18, \"detail\": \"Known shortener: bit.ly\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 14, \"detail\": \"Keywords: login, free\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 3, \"detail\": \"login\"}, {\"source\": \"nlp\", \"rule\": \"Reward / bait\", \"points\": 4, \"detail\": \"free\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://bit.ly/free-login','2026-02-26 07:04:37'),(3,6936155788,NULL,'https://www.youtube.com/channel/UC9ui29SMJKPRCy0rx-Wv0VQ','safe',0,'LOW','No red flags','[]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','https://www.youtube.com/channel/UC9ui29SMJKPRCy0rx-Wv0VQ','2026-02-26 07:04:50'),(4,6936155788,NULL,'http://bit.ly/free-login','suspicious',51,'MED','Connection not encrypted (HTTP); Known shortener: bit.ly; Keywords: login, free; login; free','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL shortener\", \"points\": 18, \"detail\": \"Known shortener: bit.ly\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 14, \"detail\": \"Keywords: login, free\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 3, \"detail\": \"login\"}, {\"source\": \"nlp\", \"rule\": \"Reward / bait\", \"points\": 4, \"detail\": \"free\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://bit.ly/free-login','2026-02-26 07:05:01'),(5,6936155788,NULL,'http://bit.ly/free-login','suspicious',51,'MED','Connection not encrypted (HTTP); Known shortener: bit.ly; Keywords: login, free; login; free','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL shortener\", \"points\": 18, \"detail\": \"Known shortener: bit.ly\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 14, \"detail\": \"Keywords: login, free\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 3, \"detail\": \"login\"}, {\"source\": \"nlp\", \"rule\": \"Reward / bait\", \"points\": 4, \"detail\": \"free\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://bit.ly/free-login','2026-02-26 08:12:46');
/*!40000 ALTER TABLE `scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('automatic_backup_enabled','true','2026-02-26 06:34:59'),('auto_backup','true','2026-02-26 06:34:59'),('backup_schedule','Daily 3:00 AM','2026-02-26 06:34:59'),('backup_time_of_day','03:00','2026-02-26 06:34:59'),('last_backup_at','2026-02-26T09:48:14.022034+00:00','2026-02-26 09:48:14'),('retention_days','7','2026-02-26 06:34:59'),('system_name','SIT Admin Panel','2026-02-26 06:34:59'),('timezone','Asia/Kuala_Lumpur','2026-02-26 06:34:59');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_security`
--

DROP TABLE IF EXISTS `user_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_security` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `totp_enabled` tinyint(1) NOT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  `mfa_required` tinyint(1) NOT NULL,
  `session_timeout_minutes` int(11) NOT NULL,
  `recovery_codes_hash` text DEFAULT NULL,
  `twofa_failed_attempts` int(11) NOT NULL,
  `twofa_locked_until` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `ix_user_security_id` (`id`),
  CONSTRAINT `user_security_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `admin_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_security`
--

LOCK TABLES `user_security` WRITE;
/*!40000 ALTER TABLE `user_security` DISABLE KEYS */;
INSERT INTO `user_security` VALUES (1,1,1,'JBSWY3DPEHPK3PXP',1,480,NULL,0,NULL),(2,3,1,'JBSWY3DPEHPK3PXP',1,480,NULL,0,NULL);
/*!40000 ALTER TABLE `user_security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('admin','editor','viewer') NOT NULL,
  `status` enum('active','inactive','suspended') NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `last_login_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_email` (`email`),
  KEY `ix_users_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'sit_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-26 18:03:13
