-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: sit_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_admin_users_email` (`email`),
  KEY `ix_admin_users_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'bot@example.com','$2b$12$N8Juv500eqF0sJ6Qp101/.E0XOdJAumulj00dJXuf3fsJN2ref/yO','admin','2026-03-01 09:40:31'),(2,'nalcsbaru@gmail.com','$2b$12$RsYL.Ggm923mdQQflm1WkOxvHlEmdP6zl/4o0TZpS/5CqQIXqaj/y','admin','2026-03-01 09:40:31');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actor_email` varchar(255) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_audit_logs_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-03-01 09:53:13'),(2,'bot@example.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-03-01 09:53:32'),(3,'nalcsbaru@gmail.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-03-01 09:53:46'),(4,'nalcsbaru@gmail.com','POST /reports','http://127.0.0.1:8002/reports','127.0.0.1',NULL,NULL,'2026-03-01 09:55:03'),(5,'nalcsbaru@gmail.com','PATCH /reports/1','http://127.0.0.1:8002/reports/1','127.0.0.1',NULL,NULL,'2026-03-01 09:55:05'),(6,'nalcsbaru@gmail.com','PATCH /reports/1','http://127.0.0.1:8002/reports/1','127.0.0.1',NULL,NULL,'2026-03-01 09:55:49'),(7,'nalcsbaru@gmail.com','POST /reports','http://127.0.0.1:8002/reports','127.0.0.1',NULL,NULL,'2026-03-01 09:56:40'),(8,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-03-01 10:13:13'),(9,'nalcsbaru@gmail.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-03-01 10:13:47'),(10,'bot@example.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-03-01 10:14:14'),(11,'nalcsbaru@gmail.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-03-01 10:15:04'),(12,'nalcsbaru@gmail.com','POST /security/2fa/disable','http://127.0.0.1:8002/security/2fa/disable','127.0.0.1',NULL,NULL,'2026-03-01 12:24:21'),(13,'nalcsbaru@gmail.com','POST /security/2fa/disable','http://127.0.0.1:8002/security/2fa/disable','127.0.0.1',NULL,NULL,'2026-03-01 12:24:25'),(14,'nalcsbaru@gmail.com','POST /security/2fa/disable','http://127.0.0.1:8002/security/2fa/disable','127.0.0.1',NULL,NULL,'2026-03-01 12:24:25'),(15,'nalcsbaru@gmail.com','POST /reports','http://127.0.0.1:8002/reports','127.0.0.1',NULL,NULL,'2026-03-01 14:16:07'),(16,'nalcsbaru@gmail.com','PATCH /reports/4','http://127.0.0.1:8002/reports/4','127.0.0.1',NULL,NULL,'2026-03-01 14:16:15'),(17,'nalcsbaru@gmail.com','PATCH /reports/4','http://127.0.0.1:8002/reports/4','127.0.0.1',NULL,NULL,'2026-03-01 14:16:17'),(18,'nalcsbaru@gmail.com','PATCH /reports/4','http://127.0.0.1:8002/reports/4','127.0.0.1',NULL,NULL,'2026-03-01 14:16:19'),(19,'nalcsbaru@gmail.com','PATCH /reports/4','http://127.0.0.1:8002/reports/4','127.0.0.1',NULL,NULL,'2026-03-01 14:16:20'),(20,'nalcsbaru@gmail.com','POST /reports','http://127.0.0.1:8002/reports','127.0.0.1',NULL,NULL,'2026-03-01 14:17:37'),(21,'nalcsbaru@gmail.com','CREATE_NOTIFICATION','aca',NULL,NULL,NULL,'2026-03-01 14:18:06'),(22,'nalcsbaru@gmail.com','POST /notifications','http://127.0.0.1:8002/notifications','127.0.0.1',NULL,NULL,'2026-03-01 14:18:06'),(23,'nalcsbaru@gmail.com','RUN_BACKUP',NULL,NULL,'{\"type\": \"db_only\"}',NULL,'2026-03-01 14:18:20'),(24,'nalcsbaru@gmail.com','POST /backup/run','http://127.0.0.1:8002/backup/run','127.0.0.1',NULL,NULL,'2026-03-01 14:18:20'),(25,'nalcsbaru@gmail.com','RUN_BACKUP',NULL,NULL,'{\"type\": \"db_only\"}',NULL,'2026-03-01 14:18:25'),(26,'nalcsbaru@gmail.com','POST /backup/run','http://127.0.0.1:8002/backup/run','127.0.0.1',NULL,NULL,'2026-03-01 14:18:25'),(27,'bot@example.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-03-01 14:36:23'),(28,'bot@example.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-03-01 14:38:16'),(29,'nalcsbaru@gmail.com','POST /reports','http://127.0.0.1:8002/reports','127.0.0.1',NULL,NULL,'2026-03-01 14:38:45'),(30,'bot@example.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,NULL,'2026-03-01 14:42:39'),(31,'bot@example.com','LOGIN_SUCCESS',NULL,NULL,NULL,NULL,'2026-03-01 15:59:16'),(32,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,NULL,'2026-03-01 15:59:16'),(33,'nalcsbaru@gmail.com','RUN_BACKUP',NULL,NULL,'{\"type\": \"db_only\"}',NULL,'2026-03-01 15:59:57'),(34,'nalcsbaru@gmail.com','POST /backup/run','http://127.0.0.1:8002/backup/run','127.0.0.1',NULL,NULL,'2026-03-01 15:59:57');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `started_at` timestamp NULL DEFAULT current_timestamp(),
  `finished_at` timestamp NULL DEFAULT NULL,
  `status` enum('success','failed','running') NOT NULL,
  `size_bytes` bigint(20) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `checksum_sha256` varchar(64) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `summary_file_path` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backup_history_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
INSERT INTO `backup_history` VALUES (1,'2026-03-01 06:18:20','2026-03-01 06:18:20','success',3788,'C:\\Users\\Ainal Aiman\\Documents\\Scammer Identification and Validation Tool\\backend\\backups\\backup-20260301-141820.zip','f6a06c3c0ca33c090c6a65ec99b7580e85bca1d38cca6fe3b2170dbe1aad1994',NULL,'db_only','C:\\Users\\Ainal Aiman\\Documents\\Scammer Identification and Validation Tool\\backend\\backups\\backup-20260301-141820-summary.json'),(2,'2026-03-01 06:18:25','2026-03-01 06:18:25','success',3987,'C:\\Users\\Ainal Aiman\\Documents\\Scammer Identification and Validation Tool\\backend\\backups\\backup-20260301-141825.zip','7340b59284921764978913c7e3688ba91979bb248ea8103ac2846abed00c5258',NULL,'db_only','C:\\Users\\Ainal Aiman\\Documents\\Scammer Identification and Validation Tool\\backend\\backups\\backup-20260301-141825-summary.json'),(3,'2026-03-01 07:59:57',NULL,'running',NULL,NULL,NULL,NULL,'db_only',NULL);
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_email` varchar(255) DEFAULT NULL,
  `scope_json` text DEFAULT NULL,
  `status` enum('queued','running','done','failed') NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `finished_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backups_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_scope` enum('all','admin','editor','viewer','selected') NOT NULL,
  `recipient_user_id` int(11) DEFAULT NULL,
  `type` enum('info','warning','alert','success') NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_notifications_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'all',NULL,'warning','aca','cawa',0,'2026-03-01 14:18:06');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_user_id` bigint(20) DEFAULT NULL,
  `telegram_username` varchar(80) DEFAULT NULL,
  `link` text DEFAULT NULL,
  `report_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` enum('new','investigating','resolved') NOT NULL,
  `assignee` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `priority` enum('low','medium','high','critical') NOT NULL,
  `due_at` timestamp NULL DEFAULT NULL,
  `linked_scan_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `linked_scan_id` (`linked_scan_id`),
  KEY `ix_reports_id` (`id`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`linked_scan_id`) REFERENCES `scans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (1,NULL,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam','sd','resolved',NULL,NULL,'medium','2026-03-04 01:55:02',NULL,'2026-03-01 09:55:02'),(2,NULL,NULL,'https://www.y8.com/','scam','adfa','new',NULL,NULL,'medium','2026-03-04 01:56:40',NULL,'2026-03-01 09:56:40'),(3,NULL,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam','Verdict: scam | Score: 85 | Threat: HIGH | Reasons: Connection not encrypted (HTTP); URL contains @ - real destination may be hidden; Keywords: login, verify, otp, bank, urgent; 5 phishing-related keywords in URL; 4 domain levels | Scan #3 at 2026-03-01 18:13:47','new',NULL,'Duplicate scan #4\nDuplicate scan #6','high','2026-03-02 02:13:47',3,'2026-03-01 10:13:47'),(4,NULL,NULL,'http://evil-phishing.test','phishing','JANGAN BUKAK THIS FILE','resolved',NULL,NULL,'medium','2026-03-04 06:16:07',5,'2026-03-01 14:16:07'),(5,NULL,NULL,NULL,'phishing','SCAM NI','new',NULL,NULL,'medium','2026-03-04 06:17:37',NULL,'2026-03-01 14:17:37'),(6,NULL,NULL,'https://muftiwp.gov.my/images/falak/takwim/tarikh_penting/TARIKH_Penting_Islam_2026.pdf','scam','Auto-created from scan #7: No red flags','new',NULL,NULL,'medium','2026-03-04 06:38:45',NULL,'2026-03-01 14:38:45');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scans`
--

DROP TABLE IF EXISTS `scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_user_id` bigint(20) DEFAULT NULL,
  `telegram_username` varchar(80) DEFAULT NULL,
  `link` text NOT NULL,
  `verdict` enum('safe','suspicious','scam') NOT NULL,
  `score` int(11) NOT NULL,
  `threat_level` varchar(10) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `breakdown` text DEFAULT NULL,
  `intel_summary` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_scans_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scans`
--

LOCK TABLES `scans` WRITE;
/*!40000 ALTER TABLE `scans` DISABLE KEYS */;
INSERT INTO `scans` VALUES (1,6936155788,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam',99,'HIGH','Connection not encrypted (HTTP); URL contains @ - real destination may be hidden; Keywords: login, verify, otp, bank, urgent; 5 phishing-related keywords in URL; 4 domain levels; urgent; verify, login; bank','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL Userinfo (@) Trick\", \"points\": 15, \"detail\": \"URL contains @ - real destination may be hidden\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 28, \"detail\": \"Keywords: login, verify, otp, bank, urgent\"}, {\"source\": \"heuristic\", \"rule\": \"High keyword concentration\", \"points\": 20, \"detail\": \"5 phishing-related keywords in URL\"}, {\"source\": \"heuristic\", \"rule\": \"Excessive subdomains\", \"points\": 10, \"detail\": \"4 domain levels\"}, {\"source\": \"nlp\", \"rule\": \"Urgency language\", \"points\": 4, \"detail\": \"urgent\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 6, \"detail\": \"verify, login\"}, {\"source\": \"nlp\", \"rule\": \"Threat indicators\", \"points\": 4, \"detail\": \"bank\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://example.com@safe.example.com/login/verify/otp/bank/urgent','2026-03-01 09:53:32'),(2,NULL,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam',85,'HIGH','Connection not encrypted (HTTP); URL contains @ - real destination may be hidden; Keywords: login, verify, otp, bank, urgent; 5 phishing-related keywords in URL; 4 domain levels','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL Userinfo (@) Trick\", \"points\": 15, \"detail\": \"URL contains @ - real destination may be hidden\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 28, \"detail\": \"Keywords: login, verify, otp, bank, urgent\"}, {\"source\": \"heuristic\", \"rule\": \"High keyword concentration\", \"points\": 20, \"detail\": \"5 phishing-related keywords in URL\"}, {\"source\": \"heuristic\", \"rule\": \"Excessive subdomains\", \"points\": 10, \"detail\": \"4 domain levels\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}',NULL,'2026-03-01 09:53:46'),(3,NULL,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam',85,'HIGH','Connection not encrypted (HTTP); URL contains @ - real destination may be hidden; Keywords: login, verify, otp, bank, urgent; 5 phishing-related keywords in URL; 4 domain levels','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL Userinfo (@) Trick\", \"points\": 15, \"detail\": \"URL contains @ - real destination may be hidden\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 28, \"detail\": \"Keywords: login, verify, otp, bank, urgent\"}, {\"source\": \"heuristic\", \"rule\": \"High keyword concentration\", \"points\": 20, \"detail\": \"5 phishing-related keywords in URL\"}, {\"source\": \"heuristic\", \"rule\": \"Excessive subdomains\", \"points\": 10, \"detail\": \"4 domain levels\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}',NULL,'2026-03-01 10:13:47'),(4,6936155788,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam',99,'HIGH','Connection not encrypted (HTTP); URL contains @ - real destination may be hidden; Keywords: login, verify, otp, bank, urgent; 5 phishing-related keywords in URL; 4 domain levels; urgent; verify, login; bank','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL Userinfo (@) Trick\", \"points\": 15, \"detail\": \"URL contains @ - real destination may be hidden\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 28, \"detail\": \"Keywords: login, verify, otp, bank, urgent\"}, {\"source\": \"heuristic\", \"rule\": \"High keyword concentration\", \"points\": 20, \"detail\": \"5 phishing-related keywords in URL\"}, {\"source\": \"heuristic\", \"rule\": \"Excessive subdomains\", \"points\": 10, \"detail\": \"4 domain levels\"}, {\"source\": \"nlp\", \"rule\": \"Urgency language\", \"points\": 4, \"detail\": \"urgent\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 6, \"detail\": \"verify, login\"}, {\"source\": \"nlp\", \"rule\": \"Threat indicators\", \"points\": 4, \"detail\": \"bank\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://example.com@safe.example.com/login/verify/otp/bank/urgent','2026-03-01 10:14:14'),(5,NULL,NULL,'http://evil-phishing.test','safe',12,'LOW','Connection not encrypted (HTTP)','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}',NULL,'2026-03-01 10:15:04'),(6,6936155788,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam',99,'HIGH','Connection not encrypted (HTTP); URL contains @ - real destination may be hidden; Keywords: login, verify, otp, bank, urgent; 5 phishing-related keywords in URL; 4 domain levels; urgent; verify, login; bank','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL Userinfo (@) Trick\", \"points\": 15, \"detail\": \"URL contains @ - real destination may be hidden\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 28, \"detail\": \"Keywords: login, verify, otp, bank, urgent\"}, {\"source\": \"heuristic\", \"rule\": \"High keyword concentration\", \"points\": 20, \"detail\": \"5 phishing-related keywords in URL\"}, {\"source\": \"heuristic\", \"rule\": \"Excessive subdomains\", \"points\": 10, \"detail\": \"4 domain levels\"}, {\"source\": \"nlp\", \"rule\": \"Urgency language\", \"points\": 4, \"detail\": \"urgent\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 6, \"detail\": \"verify, login\"}, {\"source\": \"nlp\", \"rule\": \"Threat indicators\", \"points\": 4, \"detail\": \"bank\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://example.com@safe.example.com/login/verify/otp/bank/urgent','2026-03-01 14:36:23'),(7,6479881840,NULL,'https://muftiwp.gov.my/images/falak/takwim/tarikh_penting/TARIKH_Penting_Islam_2026.pdf','safe',0,'LOW','No red flags','[]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','https://muftiwp.gov.my/images/falak/takwim/tarikh_penting/TARIKH_Penting_Islam_2026.pdf','2026-03-01 14:38:16'),(8,6936155788,NULL,'https://muftiwp.gov.my/images/falak/takwim/tarikh_penting/TARIKH_Penting_Islam_2026.pdf','safe',0,'LOW','No red flags','[]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','https://muftiwp.gov.my/images/falak/takwim/tarikh_penting/TARIKH_Penting_Islam_2026.pdf','2026-03-01 14:42:39');
/*!40000 ALTER TABLE `scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('automatic_backup_enabled','true','2026-03-01 09:40:31'),('auto_backup','true','2026-03-01 09:40:31'),('backup_schedule','Daily 3:00 AM','2026-03-01 09:40:31'),('backup_time_of_day','03:00','2026-03-01 09:40:31'),('last_backup_at','2026-03-01T14:18:25.453313+00:00','2026-03-01 14:18:25'),('retention_days','7','2026-03-01 09:40:31'),('system_name','SIT Admin Panel','2026-03-01 09:40:31'),('timezone','Asia/Kuala_Lumpur','2026-03-01 09:40:31');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_security`
--

DROP TABLE IF EXISTS `user_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_security` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `totp_enabled` tinyint(1) NOT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  `mfa_required` tinyint(1) NOT NULL,
  `session_timeout_minutes` int(11) NOT NULL,
  `recovery_codes_hash` text DEFAULT NULL,
  `twofa_failed_attempts` int(11) NOT NULL,
  `twofa_locked_until` timestamp NULL DEFAULT NULL,
  `password_hint` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `ix_user_security_id` (`id`),
  CONSTRAINT `user_security_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `admin_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_security`
--

LOCK TABLES `user_security` WRITE;
/*!40000 ALTER TABLE `user_security` DISABLE KEYS */;
INSERT INTO `user_security` VALUES (1,2,1,'JBSWY3DPEHPK3PXP',1,480,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `user_security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('admin','editor','viewer') NOT NULL,
  `status` enum('active','inactive','suspended') NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `last_login_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_email` (`email`),
  KEY `ix_users_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'sit_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-01 23:59:57
