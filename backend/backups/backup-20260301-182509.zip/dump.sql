-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: sit_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `last_user_agent` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_admin_users_email` (`email`),
  KEY `ix_admin_users_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'bot@example.com','$2b$12$ww0Vq0ZABTuGYj/jlmPH1.StWXwnT2tdaeOQXt8/Z85o.WRXhnsVq','admin','2026-03-01 18:21:03','2026-03-01 10:21:07','127.0.0.1','python-requests/2.32.5'),(2,'nalcsbaru@gmail.com','$2b$12$QfgVRDf1q.3WGWN2ubxGBepYXvXNse0Sw3uO1Dt0tB0KE5xzTY9XO','admin','2026-03-01 18:21:03','2026-03-01 10:23:24','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actor_email` varchar(255) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_audit_logs_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'bot@example.com','LOGIN_SUCCESS',NULL,'127.0.0.1',NULL,'python-requests/2.32.5','2026-03-01 18:21:07'),(2,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,'python-requests/2.32.5','2026-03-01 18:21:07'),(3,'bot@example.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,'python-requests/2.32.5','2026-03-01 18:21:37'),(4,'bot@example.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,'python-requests/2.32.5','2026-03-01 18:22:34'),(5,NULL,'POST /auth/login','http://127.0.0.1:8002/auth/login','127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','2026-03-01 18:23:06'),(6,NULL,'POST /auth/send-email-otp','http://127.0.0.1:8002/auth/send-email-otp','127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','2026-03-01 18:23:11'),(7,'nalcsbaru@gmail.com','LOGIN_SUCCESS',NULL,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','2026-03-01 18:23:24'),(8,NULL,'POST /auth/verify-2fa','http://127.0.0.1:8002/auth/verify-2fa','127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','2026-03-01 18:23:24'),(9,'nalcsbaru@gmail.com','POST /scans','http://127.0.0.1:8002/scans','127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','2026-03-01 18:24:27'),(10,'nalcsbaru@gmail.com','RUN_BACKUP','backup_id=1','127.0.0.1','{\"type\": \"db_only\"}','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','2026-03-01 18:25:09'),(11,'nalcsbaru@gmail.com','POST /backup/run','http://127.0.0.1:8002/backup/run','127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','2026-03-01 18:25:09');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `started_at` timestamp NULL DEFAULT current_timestamp(),
  `finished_at` timestamp NULL DEFAULT NULL,
  `status` enum('success','failed','running') NOT NULL,
  `size_bytes` bigint(20) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `checksum_sha256` varchar(64) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `summary_file_path` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backup_history_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
INSERT INTO `backup_history` VALUES (1,'2026-03-01 10:25:09',NULL,'running',NULL,NULL,NULL,NULL,'db_only',NULL);
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_email` varchar(255) DEFAULT NULL,
  `scope_json` text DEFAULT NULL,
  `status` enum('queued','running','done','failed') NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `finished_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_backups_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_scope` enum('all','admin','editor','viewer','selected') NOT NULL,
  `recipient_user_id` int(11) DEFAULT NULL,
  `type` enum('info','warning','alert','success') NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_notifications_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_user_id` bigint(20) DEFAULT NULL,
  `telegram_username` varchar(80) DEFAULT NULL,
  `link` text DEFAULT NULL,
  `report_type` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` enum('new','investigating','resolved') NOT NULL,
  `assignee` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `priority` enum('low','medium','high','critical') NOT NULL,
  `due_at` timestamp NULL DEFAULT NULL,
  `linked_scan_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `linked_scan_id` (`linked_scan_id`),
  KEY `ix_reports_id` (`id`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`linked_scan_id`) REFERENCES `scans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (1,6936155788,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam','Verdict: scam | Score: 99 | Threat: HIGH | Reasons: Connection not encrypted (HTTP); URL contains @ - real destination may be hidden; Keywords: login, verify, otp, bank, urgent; 5 phishing-related keywords in URL; 4 domain levels; urgent; verify, login; bank | Scan #2 at 2026-03-02 02:22:34','new',NULL,NULL,'critical','2026-03-01 16:22:34',2,'2026-03-01 18:22:34');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scans`
--

DROP TABLE IF EXISTS `scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_user_id` bigint(20) DEFAULT NULL,
  `telegram_username` varchar(80) DEFAULT NULL,
  `link` text NOT NULL,
  `verdict` enum('safe','suspicious','scam') NOT NULL,
  `score` int(11) NOT NULL,
  `threat_level` varchar(10) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `breakdown` text DEFAULT NULL,
  `intel_summary` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_scans_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scans`
--

LOCK TABLES `scans` WRITE;
/*!40000 ALTER TABLE `scans` DISABLE KEYS */;
INSERT INTO `scans` VALUES (1,6936155788,NULL,'https://muftiwp.gov.my/images/falak/takwim/tarikh_penting/TARIKH_Penting_Islam_2026.pdf','safe',0,'LOW','No red flags','[]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','https://muftiwp.gov.my/images/falak/takwim/tarikh_penting/TARIKH_Penting_Islam_2026.pdf','2026-03-01 18:21:37'),(2,6936155788,NULL,'http://example.com@safe.example.com/login/verify/otp/bank/urgent','scam',99,'HIGH','Connection not encrypted (HTTP); URL contains @ - real destination may be hidden; Keywords: login, verify, otp, bank, urgent; 5 phishing-related keywords in URL; 4 domain levels; urgent; verify, login; bank','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL Userinfo (@) Trick\", \"points\": 15, \"detail\": \"URL contains @ - real destination may be hidden\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 28, \"detail\": \"Keywords: login, verify, otp, bank, urgent\"}, {\"source\": \"heuristic\", \"rule\": \"High keyword concentration\", \"points\": 20, \"detail\": \"5 phishing-related keywords in URL\"}, {\"source\": \"heuristic\", \"rule\": \"Excessive subdomains\", \"points\": 10, \"detail\": \"4 domain levels\"}, {\"source\": \"nlp\", \"rule\": \"Urgency language\", \"points\": 4, \"detail\": \"urgent\"}, {\"source\": \"nlp\", \"rule\": \"Call-to-action\", \"points\": 6, \"detail\": \"verify, login\"}, {\"source\": \"nlp\", \"rule\": \"Threat indicators\", \"points\": 4, \"detail\": \"bank\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}','http://example.com@safe.example.com/login/verify/otp/bank/urgent','2026-03-01 18:22:34'),(3,NULL,NULL,'http://bit.ly/free-login','safe',44,'LOW','Connection not encrypted (HTTP); Known shortener: bit.ly; Keywords: login, free','[{\"source\": \"heuristic\", \"rule\": \"HTTPS missing\", \"points\": 12, \"detail\": \"Connection not encrypted (HTTP)\"}, {\"source\": \"heuristic\", \"rule\": \"URL shortener\", \"points\": 18, \"detail\": \"Known shortener: bit.ly\"}, {\"source\": \"heuristic\", \"rule\": \"Suspicious keywords\", \"points\": 14, \"detail\": \"Keywords: login, free\"}]','{\"virustotal\": {\"provider\": \"virustotal\", \"available\": false, \"found\": false, \"positives\": 0, \"total\": 0, \"threat_label\": null, \"score_contribution\": 0, \"error\": \"API key not configured (optional)\"}, \"urlhaus\": {\"provider\": \"urlhaus\", \"available\": true, \"found\": false, \"threat\": null, \"tags\": [], \"score_contribution\": 0}}',NULL,'2026-03-01 18:24:27');
/*!40000 ALTER TABLE `scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('automatic_backup_enabled','true','2026-03-01 18:21:03'),('auto_backup','true','2026-03-01 18:21:03'),('backup_schedule','Daily 3:00 AM','2026-03-01 18:21:03'),('backup_time_of_day','03:00','2026-03-01 18:21:03'),('retention_days','7','2026-03-01 18:21:03'),('system_name','SIT Admin Panel','2026-03-01 18:21:03'),('timezone','Asia/Kuala_Lumpur','2026-03-01 18:21:03');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_security`
--

DROP TABLE IF EXISTS `user_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_security` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `totp_enabled` tinyint(1) NOT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  `mfa_required` tinyint(1) NOT NULL,
  `session_timeout_minutes` int(11) NOT NULL,
  `recovery_codes_hash` text DEFAULT NULL,
  `twofa_failed_attempts` int(11) NOT NULL,
  `twofa_locked_until` timestamp NULL DEFAULT NULL,
  `password_hint` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `ix_user_security_id` (`id`),
  CONSTRAINT `user_security_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `admin_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_security`
--

LOCK TABLES `user_security` WRITE;
/*!40000 ALTER TABLE `user_security` DISABLE KEYS */;
INSERT INTO `user_security` VALUES (1,2,1,'JBSWY3DPEHPK3PXP',1,480,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `user_security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('admin','editor','viewer') NOT NULL,
  `status` enum('active','inactive','suspended') NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `last_login_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_email` (`email`),
  KEY `ix_users_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'sit_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-02  2:25:09
